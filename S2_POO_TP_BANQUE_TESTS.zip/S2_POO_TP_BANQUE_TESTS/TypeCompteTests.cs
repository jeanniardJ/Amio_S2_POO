﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S2_POO_TP_BANQUE_TESTS
{
    internal enum TypeCompteTests
    {
        CompteCourant,
        CompteEpargne
    }
}
